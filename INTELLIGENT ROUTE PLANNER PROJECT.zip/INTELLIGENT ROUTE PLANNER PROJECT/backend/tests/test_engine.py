import sys
import os

# Ensure backend root is in sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

import pytest
from data.mock_map import build_road_graph, MOCK_RESTRICTED_POLYGONS
from models.schemas import Vehicle, DeliveryStop
from engine.dynamic_astar import DynamicAStarEngine
from engine.vrp_solver import ORToolsVRPSolver
from engine.rule_engine import SymbolicRuleEngine
from engine.metaheuristics import MetaHeuristicSolver

@pytest.fixture
def graph():
    return build_road_graph()

@pytest.fixture
def standard_vehicle():
    return Vehicle(
        vehicle_id="V001",
        name="Standard Delivery Truck",
        capacity_kg=1500.0,
        height_m=3.2,
        weight_tons=7.5,
        is_hazmat=False,
        max_continuous_drive_hours=4.0
    )

def test_dynamic_astar_optimal_path(graph, standard_vehicle):
    engine = DynamicAStarEngine(graph)
    route = engine.find_shortest_path("DEPOT_BLR", "NODE_CHENNAI", standard_vehicle)
    assert route.total_distance_km > 0
    assert route.total_time_min > 0
    assert len(route.path_nodes) >= 2
    assert route.path_nodes[0] == "DEPOT_BLR"
    assert route.path_nodes[-1] == "NODE_CHENNAI"

def test_dynamic_astar_via_waypoints(graph, standard_vehicle):
    engine = DynamicAStarEngine(graph)
    route = engine.find_shortest_path("DEPOT_BLR", "NODE_KOCHI", standard_vehicle, via_node_ids=["NODE_SALEM", "NODE_COIMBATORE"])
    assert route.total_distance_km > 0
    assert "NODE_SALEM" in route.path_nodes
    assert "NODE_COIMBATORE" in route.path_nodes

def test_dynamic_astar_rerouting_around_closed_road(graph, standard_vehicle):
    engine = DynamicAStarEngine(graph)
    # Get initial route
    route1 = engine.find_shortest_path("DEPOT_BLR", "NODE_CHENNAI", standard_vehicle)
    
    # Close direct link DEPOT_BLR -> NODE_CHENNAI
    graph["DEPOT_BLR"]["NODE_CHENNAI"]["speed_factor"] = 0.0
    graph["NODE_CHENNAI"]["DEPOT_BLR"]["speed_factor"] = 0.0
    
    # Re-run route search
    route2 = engine.find_shortest_path("DEPOT_BLR", "NODE_CHENNAI", standard_vehicle)
    
    assert route2.path_nodes != route1.path_nodes
    assert "NODE_CHENNAI" in route2.path_nodes

def test_rule_engine_validations(standard_vehicle):
    rule_eng = SymbolicRuleEngine()
    evals = rule_eng.validate_vehicle_profile(standard_vehicle)
    assert len(evals) >= 2
    assert all(e.passed for e in evals)

    # Violating vehicle
    invalid_vehicle = Vehicle(
        vehicle_id="V_BAD",
        name="Overweight Truck",
        weight_tons=45.0, # exceeds 40t
        max_continuous_drive_hours=6.0 # exceeds 4.5h
    )
    bad_evals = rule_eng.validate_vehicle_profile(invalid_vehicle)
    assert any(not e.passed for e in bad_evals)

def test_vrp_ortools_solver(graph, standard_vehicle):
    vrp = ORToolsVRPSolver(graph)
    stops = [
        DeliveryStop(stop_id="S1", name="Chennai Stop", node_id="NODE_CHENNAI", demand_kg=300.0),
        DeliveryStop(stop_id="S2", name="Salem Stop", node_id="NODE_SALEM", demand_kg=400.0),
    ]
    resp = vrp.solve_cvrptw("DEPOT_BLR", [standard_vehicle], stops)
    assert len(resp.routes) > 0
    assert resp.total_fleet_distance_km > 0

def test_metaheuristic_ga_solver(graph, standard_vehicle):
    meta = MetaHeuristicSolver(graph)
    stops = [
        DeliveryStop(stop_id="S1", name="Chennai Stop", node_id="NODE_CHENNAI", demand_kg=300.0),
        DeliveryStop(stop_id="S2", name="Salem Stop", node_id="NODE_SALEM", demand_kg=400.0),
    ]
    resp = meta.solve_genetic_algorithm("DEPOT_BLR", [standard_vehicle], stops, population_size=10, generations=5)
    assert len(resp.routes) > 0
