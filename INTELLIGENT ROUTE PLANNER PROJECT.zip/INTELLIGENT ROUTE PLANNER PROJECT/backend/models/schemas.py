from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Tuple, Any

class Coordinate(BaseModel):
    lat: float
    lng: float

class LocationNode(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    is_depot: bool = False
    metro_station: Optional[str] = None
    bus_terminal: Optional[str] = None

class Vehicle(BaseModel):
    vehicle_id: str
    name: str
    capacity_kg: float = 1000.0
    height_m: float = 3.2
    weight_tons: float = 7.5
    is_hazmat: bool = False
    max_continuous_drive_hours: float = 4.0

class DeliveryStop(BaseModel):
    stop_id: str
    name: str
    node_id: str
    demand_kg: float = 100.0
    time_window_start: float = 0.0   # minutes from start of shift
    time_window_end: float = 480.0   # minutes from start of shift (8 hours)
    service_time_min: float = 15.0   # unloading duration

class PolygonZone(BaseModel):
    zone_id: str
    name: str
    polygon: List[Coordinate]        # list of lat, lng defining boundary
    max_height_m: Optional[float] = None
    max_weight_tons: Optional[float] = None
    disallow_hazmat: bool = False
    is_closed: bool = False

class DynamicTrafficEvent(BaseModel):
    event_id: str
    edge_u: str
    edge_v: str
    event_type: str                   # "ACCIDENT", "CONGESTION", "WEATHER_ALERT", "ROAD_CLOSURE"
    speed_factor: float = 1.0         # 0.0 (closed) to 1.0 (free flow)
    description: str

class RoutingRequest(BaseModel):
    origin_id: Optional[str] = None
    destination_id: Optional[str] = None
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_name: Optional[str] = None
    dest_lat: Optional[float] = None
    dest_lng: Optional[float] = None
    dest_name: Optional[str] = None
    via_node_ids: List[str] = []
    transport_mode: str = "CAR"       # CAR, TRUCK, METRO, BUS, MOTORCYCLE, BICYCLE, WALKING, MULTI_MODAL
    vehicle: Optional[Vehicle] = Field(default_factory=lambda: Vehicle(vehicle_id="V-101", name="Standard Passenger Vehicle"))
    avoid_zones: List[PolygonZone] = []

class RuleEvaluation(BaseModel):
    rule_id: str
    rule_name: str
    category: str                     # "SAFETY", "LEGAL", "VEHICLE_LIMIT", "HAZARD_ZONE", "TRANSIT_POLICY"
    passed: bool
    severity: str                     # "HARD_BLOCK", "WARNING", "COMPLIANT"
    message: str
    math_proof: str                   # Exact mathematical inequality or logic statement

class RouteStep(BaseModel):
    step_index: int
    from_node: str
    to_node: str
    road_name: str
    transport_mode: str = "CAR"
    transit_line_name: Optional[str] = None
    distance_km: float
    time_min: float
    free_flow_speed_kmh: float
    live_speed_kmh: float
    dynamic_weight: float
    fare_inr: float = 0.0
    co2_kg: float = 0.0
    path_coordinates: List[Tuple[float, float]] = []
    hazards_detected: List[str] = []

class ModeLeg(BaseModel):
    leg_index: int
    transport_mode: str               # CAR, TRUCK, METRO, BUS, MOTORCYCLE, BICYCLE, WALKING
    from_name: str
    to_name: str
    line_name: Optional[str] = None
    distance_km: float
    time_min: float
    fare_inr: float = 0.0
    co2_kg: float = 0.0
    color: str
    path_coordinates: List[Tuple[float, float]] = []

class RouteSolution(BaseModel):
    route_id: str
    vehicle_id: str
    transport_mode: str = "CAR"
    total_distance_km: float
    total_time_min: float
    fare_cost_inr: float = 0.0
    co2_emissions_kg: float = 0.0
    calories_burned: float = 0.0
    transfers_count: int = 0
    path_nodes: List[str]
    path_coordinates: List[Tuple[float, float]]
    steps: List[RouteStep]
    mode_legs: List[ModeLeg] = []
    rule_evaluations: List[RuleEvaluation]
    explainability_trace: List[str]

class VRPOptimizationRequest(BaseModel):
    depot_id: str
    vehicles: List[Vehicle]
    stops: List[DeliveryStop]
    avoid_zones: List[PolygonZone] = []
    algorithm: str = "OR_TOOLS"       # "OR_TOOLS", "GENETIC", "SIMULATED_ANNEALING"

class VRPOptimizationResponse(BaseModel):
    routes: List[RouteSolution]
    total_fleet_distance_km: float
    total_fleet_time_min: float
    unassigned_stops: List[str] = []
    execution_time_ms: float
    algorithm_used: str
    symbolic_explainability: List[str]

