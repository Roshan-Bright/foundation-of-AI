import sys
import os
import asyncio
import json
import logging

# Ensure backend root is in sys.path
backend_dir = os.path.dirname(os.path.abspath(__file__))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from typing import List, Dict, Any
# pyrefly: ignore [missing-import]
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
# pyrefly: ignore [missing-import]
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import (
    RoutingRequest, RouteSolution, VRPOptimizationRequest, VRPOptimizationResponse,
    Vehicle, DynamicTrafficEvent, RuleEvaluation
)
from data.mock_map import build_road_graph, MOCK_NODES, MOCK_RESTRICTED_POLYGONS
from engine.dynamic_astar import DynamicAStarEngine
from engine.vrp_solver import ORToolsVRPSolver
from engine.rule_engine import SymbolicRuleEngine
from engine.metaheuristics import MetaHeuristicSolver

app = FastAPI(
    title="Intelligent Route Planner (Pure AI Engine)",
    description="Deterministic Operations Research, Dynamic A*, and Symbolic Rule Engine for Logistics Optimization",
    version="1.0.0"
)

# Enable CORS for React Vite frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global State
road_graph = build_road_graph()
astar_engine = DynamicAStarEngine(road_graph)
vrp_solver = ORToolsVRPSolver(road_graph)
rule_engine = SymbolicRuleEngine()
meta_solver = MetaHeuristicSolver(road_graph)

# WebSocket Connection Manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: Dict[str, Any]):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                pass

manager = ConnectionManager()

@app.get("/")
def read_root():
    return {
        "status": "ONLINE",
        "system": "Pure AI Intelligent Route Planner",
        "ml_libraries": "NONE (100% Deterministic Symbolic Logic & Operations Research)"
    }

@app.get("/api/map")
def get_map_network():
    """Return map graph nodes, edges, active live speeds, and restricted polygon hazard zones."""
    nodes = []
    for n_id, n_data in road_graph.nodes(data=True):
        nodes.append({
            "id": n_id,
            "name": n_data["name"],
            "lat": n_data["lat"],
            "lng": n_data["lng"],
            "is_depot": n_data.get("is_depot", False)
        })

    edges = []
    for u, v, e_data in road_graph.edges(data=True):
        edges.append({
            "u": u,
            "v": v,
            "road_name": e_data["road_name"],
            "distance_km": e_data["distance_km"],
            "base_speed_kmh": e_data["base_speed_kmh"],
            "live_speed_kmh": round(e_data.get("live_speed_kmh", e_data["base_speed_kmh"]) * e_data.get("speed_factor", 1.0), 1),
            "speed_factor": e_data.get("speed_factor", 1.0),
            "max_height": e_data.get("max_height", 99.0),
            "max_weight": e_data.get("max_weight", 99.0),
            "hazmat_allowed": e_data.get("hazmat_allowed", True),
            "hazards": e_data.get("hazards", [])
        })

    return {
        "nodes": nodes,
        "edges": edges,
        "avoid_zones": MOCK_RESTRICTED_POLYGONS
    }

@app.post("/api/route", response_model=RouteSolution)
def calculate_single_route(request: RoutingRequest):
    """
    Calculate 100% optimal, explainable point-to-point route using Dynamic A*.
    Checks hard symbolic logic constraints before returning path solution.
    """
    try:
        # Pre-validate vehicle profile
        vehicle_rules = rule_engine.validate_vehicle_profile(request.vehicle)
        hard_blocks = [r for r in vehicle_rules if not r.passed and r.severity == "HARD_BLOCK"]
        if hard_blocks:
            raise HTTPException(status_code=400, detail=f"Vehicle Profile Rule Violation: {hard_blocks[0].message}")

        # Dynamic A* search
        combined_avoid_zones = MOCK_RESTRICTED_POLYGONS + request.avoid_zones
        route_solution = astar_engine.find_shortest_path(
            origin_id=request.origin_id,
            destination_id=request.destination_id,
            vehicle=request.vehicle,
            avoid_zones=combined_avoid_zones,
            via_node_ids=request.via_node_ids,
            transport_mode=request.transport_mode
        )

        # Post-validate route solution
        route_rules = rule_engine.validate_route_solution(route_solution, request.vehicle, combined_avoid_zones)
        route_solution.rule_evaluations.extend(vehicle_rules + route_rules)

        return route_solution

    except ValueError as ve:
        raise HTTPException(status_code=404, detail=str(ve))
    except RuntimeError as re:
        raise HTTPException(status_code=422, detail=str(re))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Engine Error: {str(e)}")

@app.post("/api/vrp", response_model=VRPOptimizationResponse)
def optimize_fleet_vrp(request: VRPOptimizationRequest):
    """
    Solve Vehicle Routing Problem (VRP) with Time Windows & Capacity Constraints.
    Supports Google OR-Tools (Exact CP) or Genetic Algorithm (Meta-Heuristic).
    """
    try:
        combined_zones = MOCK_RESTRICTED_POLYGONS + request.avoid_zones

        if request.algorithm == "GENETIC":
            return meta_solver.solve_genetic_algorithm(
                depot_id=request.depot_id,
                vehicles=request.vehicles,
                stops=request.stops,
                avoid_zones=combined_zones
            )
        else:
            # Default: Google OR-Tools
            return vrp_solver.solve_cvrptw(
                depot_id=request.depot_id,
                vehicles=request.vehicles,
                stops=request.stops,
                avoid_zones=combined_zones
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"VRP Engine Failure: {str(e)}")

@app.post("/api/rules/validate", response_model=List[RuleEvaluation])
def validate_rules(vehicle: Vehicle):
    """Explicit endpoint to evaluate Symbolic Logic rules against a vehicle specification."""
    return rule_engine.validate_vehicle_profile(vehicle)

@app.post("/api/traffic/event")
async def inject_traffic_event(event: DynamicTrafficEvent):
    """
    Inject live real-time traffic event (Accident, Speed Drop, Road Closure).
    Immediately updates in-memory graph edge weights without re-processing entire topology,
    and broadcasts event via WebSocket to connected UI clients.
    """
    u, v = event.edge_u, event.edge_v
    if not road_graph.has_edge(u, v):
        raise HTTPException(status_code=404, detail=f"Road segment edge ({u} -> {v}) not found in map graph.")

    # Immediate state update on graph edge
    edge_data = road_graph[u][v]
    edge_data["speed_factor"] = max(0.0, min(1.0, event.speed_factor))
    
    if "hazards" not in edge_data:
        edge_data["hazards"] = []
        
    if event.speed_factor <= 0.01:
        edge_data["hazards"].append(f"ROAD_CLOSURE: {event.description}")
    else:
        edge_data["hazards"].append(f"{event.event_type}: {event.description}")

    # Also update reverse edge for bi-directional consistency
    if road_graph.has_edge(v, u):
        rev_data = road_graph[v][u]
        rev_data["speed_factor"] = edge_data["speed_factor"]
        rev_data["hazards"] = list(edge_data["hazards"])

    # Broadcast update to frontend UI clients
    broadcast_payload = {
        "type": "TRAFFIC_UPDATE",
        "event_id": event.event_id,
        "edge_u": u,
        "edge_v": v,
        "event_type": event.event_type,
        "speed_factor": event.speed_factor,
        "description": event.description,
        "message": f"Real-Time Graph Edge ({u} <-> {v}) updated. Speed factor: {event.speed_factor}."
    }
    await manager.broadcast(broadcast_payload)

    return {
        "status": "SUCCESS",
        "updated_edge": f"{u} <-> {v}",
        "new_speed_factor": event.speed_factor,
        "broadcast_sent": True
    }

@app.websocket("/ws/traffic")
async def websocket_traffic_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection open and accept ping messages
            data = await websocket.receive_text()
            await websocket.send_json({"type": "PONG", "payload": data})
    except WebSocketDisconnect:
        manager.disconnect(websocket)
