import sys
import os

# Ensure backend root is in sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from typing import List, Tuple, Dict, Any
from models.schemas import Vehicle, RouteSolution, PolygonZone, RuleEvaluation, DeliveryStop

class SymbolicRuleEngine:
    """
    Symbolic AI Rule Engine.
    Enforces deterministic safety, legal, environmental, and physical policy constraints.
    Provides complete 100% explainability trace for every rule checked.
    """

    def validate_vehicle_profile(self, vehicle: Vehicle) -> List[RuleEvaluation]:
        evaluations = []

        # Rule 1: Legal Driver Working Hours Limit
        if vehicle.max_continuous_drive_hours > 4.5:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_FMCSA_REST_BREAK",
                rule_name="FMCSA Continuous Drive Time Limit",
                category="LEGAL",
                passed=False,
                severity="HARD_BLOCK",
                message=f"Vehicle continuous drive limit ({vehicle.max_continuous_drive_hours}h) exceeds legal max 4.5h without rest break.",
                math_proof="DriveTime <= 4.5h per 49 CFR § 395.3"
            ))
        else:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_FMCSA_REST_BREAK",
                rule_name="FMCSA Continuous Drive Time Limit",
                category="LEGAL",
                passed=True,
                severity="COMPLIANT",
                message=f"Vehicle continuous drive limit ({vehicle.max_continuous_drive_hours}h) satisfies legal bounds.",
                math_proof="DriveTime <= 4.5h satisfied"
            ))

        # Rule 2: Vehicle Gross Weight Legal Limit
        if vehicle.weight_tons > 40.0:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_MAX_GROSS_WEIGHT",
                rule_name="DOT Federal Bridge Gross Weight Limit",
                category="VEHICLE_LIMIT",
                passed=False,
                severity="HARD_BLOCK",
                message=f"Vehicle gross weight ({vehicle.weight_tons}t) exceeds Federal Bridge Formula limit (40.0t).",
                math_proof="W <= 500 * (L*N/(N-1) + 12*N + 36) => W <= 40.0 tons"
            ))
        else:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_MAX_GROSS_WEIGHT",
                rule_name="DOT Federal Bridge Gross Weight Limit",
                category="VEHICLE_LIMIT",
                passed=True,
                severity="COMPLIANT",
                message=f"Vehicle weight ({vehicle.weight_tons}t) within federal highway limits.",
                math_proof="Vehicle Weight <= 40.0 tons satisfied"
            ))

        return evaluations

    def validate_route_solution(self, route: RouteSolution, vehicle: Vehicle, avoid_zones: List[PolygonZone]) -> List[RuleEvaluation]:
        evaluations = []

        # Check Total Route Duration against mandatory break
        drive_time_hours = route.total_time_min / 60.0
        if drive_time_hours > vehicle.max_continuous_drive_hours:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_MANDATORY_BREAK_INSERTION",
                rule_name="Mandatory Driver Rest Break Rule",
                category="LEGAL",
                passed=False,
                severity="WARNING",
                message=f"Route duration ({round(drive_time_hours, 2)}h) exceeds continuous drive limit ({vehicle.max_continuous_drive_hours}h). 30-min break node required.",
                math_proof="RouteDuration > ContinuousDriveLimit => Insert Break Stop"
            ))
        else:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_MANDATORY_BREAK_INSERTION",
                rule_name="Mandatory Driver Rest Break Rule",
                category="LEGAL",
                passed=True,
                severity="COMPLIANT",
                message=f"Route duration ({round(drive_time_hours, 2)}h) complies with shift bounds.",
                math_proof="RouteDuration <= ContinuousDriveLimit"
            ))

        # Check Hazardous Cargo on Path
        has_hazmat_violation = False
        for step in route.steps:
            for hazard in step.hazards_detected:
                if "Hazmat Prohibited" in hazard:
                    has_hazmat_violation = True
                    break

        if has_hazmat_violation:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_HAZMAT_TUNNEL",
                rule_name="Hazmat Tunnel Restriction",
                category="SAFETY",
                passed=False,
                severity="HARD_BLOCK",
                message="Route traverses restricted Hazmat tunnel or zone.",
                math_proof="HazmatVehicle AND RestrictedTunnel = FORBIDDEN"
            ))
        else:
            evaluations.append(RuleEvaluation(
                rule_id="RULE_HAZMAT_TUNNEL",
                rule_name="Hazmat Tunnel Restriction",
                category="SAFETY",
                passed=True,
                severity="COMPLIANT",
                message="No Hazmat policy violations detected on path.",
                math_proof="Hazmat Segments = 0"
            ))

        return evaluations
