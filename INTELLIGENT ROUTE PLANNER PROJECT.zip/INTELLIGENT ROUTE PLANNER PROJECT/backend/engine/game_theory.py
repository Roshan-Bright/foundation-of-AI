import networkx as nx
from typing import Dict, List, Tuple

class GameTheoryCongestionBalancer:
    """
    Algorithmic Game Theory & Wardrop User Equilibrium Congestion Engine.
    Prevents fleet self-congestion by dynamically penalizing edges traversed by multiple vehicles
    using the Bureau of Public Roads (BPR) volume-delay function:
    
    t_e(V_e) = t_0(e) * [ 1 + alpha * (V_e / C_e)^beta ]
    """

    def __init__(self, alpha: float = 0.15, beta: float = 4.0, default_capacity: float = 5.0):
        self.alpha = alpha
        self.beta = beta
        self.default_capacity = default_capacity

    def apply_bpr_congestion_weights(self, graph: nx.DiGraph, fleet_edge_volumes: Dict[Tuple[str, str], int]) -> Dict[Tuple[str, str], float]:
        """
        Calculates equilibrium edge travel times given fleet vehicle allocations on each road segment.
        """
        bpr_penalized_weights: Dict[Tuple[str, str], float] = {}

        for u, v, edge_data in graph.edges(data=True):
            base_speed = edge_data.get("base_speed_kmh", 50.0)
            speed_factor = edge_data.get("speed_factor", 1.0)
            dist_km = edge_data["distance_km"]

            # Free flow time in minutes
            t0 = (dist_km / (base_speed * speed_factor)) * 60.0

            # Active vehicle volume on this edge
            volume = fleet_edge_volumes.get((u, v), 0) + fleet_edge_volumes.get((v, u), 0)
            capacity = edge_data.get("capacity", self.default_capacity)

            # BPR Volume-Delay Cost
            congestion_factor = 1.0 + self.alpha * ((volume / capacity) ** self.beta)
            penalized_time = t0 * congestion_factor

            bpr_penalized_weights[(u, v)] = penalized_time

        return bpr_penalized_weights
