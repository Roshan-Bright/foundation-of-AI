# Pure AI Intelligent Route Planner (No Machine Learning)

A high-performance, 100% deterministic, explainable, and compliant **Intelligent Route Planner & Vehicle Fleet Dispatcher** built with **Operations Research**, **Dynamic A* Pathfinding**, **Symbolic Logic Rules**, and **Real-Time WebSockets**.

This project strictly avoids machine learning models, neural networks, or black-box predictions. Every route decision, reroute event, or fleet allocation is 100% traceable to mathematical proofs and explicit symbolic rules.

---

## 🌟 Key Features

1. **Dynamic A* Search Engine (`engine/dynamic_astar.py`)**:
   - Admissible heuristic $h(n) = \frac{\text{Haversine}(n, \text{Goal})}{\text{MaxSpeed}_{\text{network}}}$.
   - Instant edge weight re-calculation under real-time traffic events without re-building map topology.
2. **Google OR-Tools CVRPTW Solver (`engine/vrp_solver.py`)**:
   - Solves Capacitated Vehicle Routing Problems with Customer Time Windows.
   - Enforces driver working hour limits and spatial polygon avoidance zones.
3. **Meta-Heuristic Fleet Solver (`engine/metaheuristics.py`)**:
   - Pure Genetic Algorithm (GA) with Ordered Crossover (OX) and 2-Opt Inversion for large-scale fleet operations.
4. **Symbolic Logic Rule Engine (`engine/rule_engine.py`)**:
   - Hard constraint policy validator (FMCSA 4.5h driver breaks, federal bridge weight limits, hazmat tunnel bans, bridge height clearances).
   - Generates 100% transparent audit logs with exact mathematical proofs.
5. **Algorithmic Game Theory Balancer (`engine/game_theory.py`)**:
   - Implements Bureau of Public Roads (BPR) volume-delay functions to prevent fleet self-congestion (Wardrop User Equilibrium).
6. **Real-Time Traffic Incident WebSockets (`main.py` & `TrafficSimulator.jsx`)**:
   - Instant WebSocket broadcasting of accidents, weather alerts, and road closures triggering sub-50ms dynamic re-routing.

---

## 🚀 Architecture Overview

```
best-route/
├── backend/
│   ├── main.py                  # FastAPI Application & WebSocket Server
│   ├── engine/
│   │   ├── dynamic_astar.py     # Dynamic A* Pathfinding Engine
│   │   ├── vrp_solver.py        # Google OR-Tools CVRPTW & Spatial Avoidance Solver
│   │   ├── rule_engine.py       # Symbolic Logic & Hard Constraint Rule Engine
│   │   ├── metaheuristics.py    # Genetic Algorithm & Simulated Annealing Solver
│   │   └── game_theory.py       # BPR Congestion & Wardrop Equilibrium Balancer
│   ├── models/
│   │   └── schemas.py           # Pydantic data schemas
│   ├── data/
│   │   └── mock_map.py          # City road network graph generator
│   └── tests/
│       └── test_engine.py       # Pytest unit test suite
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── App.jsx              # Main Dashboard Layout
│       ├── index.css            # Dark Glassmorphism Styling
│       ├── components/
│       │   ├── MapView.jsx      # Leaflet Map with Custom Polyline Vectors & Hazards
│       │   ├── DispatchPanel.jsx# Single & Fleet VRP Routing Controller
│       │   ├── RuleInspector.jsx# 100% Explainability Audit Console
│       │   └── TrafficSimulator.jsx # Real-time Event Injector & WS Monitor
│       └── services/
│           └── api.js           # REST & WebSocket Service Layer
└── README.md
```

---

## 🛠️ Installation & Getting Started

### Prerequisites
- **Python 3.10+**
- **Node.js 18+** & **npm**

---

### Step 1: Start Backend (FastAPI Server)

```bash
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```
- API Documentation: [http://localhost:8000/docs](http://localhost:8000/docs)
- WebSocket Endpoint: `ws://localhost:8000/ws/traffic`

---

### Step 2: Run Unit Tests

```bash
# Run backend pytest suite
$env:PYTHONPATH="backend"
python -m pytest backend/tests/test_engine.py
```

---

### Step 3: Start Frontend (React + Vite Dashboard)

```bash
cd frontend
npm install
npm run dev
```
- Open Dashboard in browser: [http://localhost:3000](http://localhost:3000)

---

## 📜 Technical Proofs & Explainability Sample

Every API response returns a `rule_evaluations` array and an `explainability_trace` log:

```json
{
  "rule_id": "RULE_A_STAR_ADMISSIBILITY",
  "rule_name": "A* Dynamic Heuristic Optimality Proof",
  "category": "MATHEMATICAL_PROOF",
  "passed": true,
  "severity": "COMPLIANT",
  "message": "Guaranteed 100% optimal path under current real-time edge weight snapshot.",
  "math_proof": "h(n) <= h*(n) holds for all nodes n in network graph G."
}
```

---

## 📄 License
MIT License. Built for deterministic, compliant, and predictable enterprise logistics.
