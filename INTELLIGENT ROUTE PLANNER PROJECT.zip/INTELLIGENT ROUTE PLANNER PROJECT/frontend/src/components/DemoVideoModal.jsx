import React, { useState, useEffect, useRef } from 'react';
import {
  Play, Pause, RotateCcw, X, Navigation, Truck,
  Activity, ShieldCheck, CheckCircle2, ChevronRight,
  ChevronLeft, Info, HelpCircle, Film, Sparkles
} from 'lucide-react';

const CHAPTERS = [
  {
    id: 1,
    title: '1. Select Nodes & Vehicle Specs',
    time: '0:00 - 0:10',
    description: 'Select origin and destination nodes on the map or panel. Define height, weight, payload, and Hazmat policies.',
    color: '#3b82f6',
    icon: Navigation,
    animationType: 'NODES'
  },
  {
    id: 2,
    title: '2. Compute Optimal Route (A*)',
    time: '0:10 - 0:20',
    description: 'Click "Compute Optimal Route" to trigger dynamic A* pathfinding that respects all physical constraints.',
    color: '#10b981',
    icon: Navigation,
    animationType: 'ASTAR'
  },
  {
    id: 3,
    title: '3. Run Multi-Vehicle Fleet VRP',
    time: '0:20 - 0:30',
    description: 'Switch to the Fleet CVRPTW tab and click "Run Fleet VRP Solver" to assign multiple vehicles to customer time windows.',
    color: '#8b5cf6',
    icon: Truck,
    animationType: 'VRP'
  },
  {
    id: 4,
    title: '4. Real-Time Traffic Simulator',
    time: '0:30 - 0:40',
    description: 'Inject accidents or heavy congestion on road segments to watch automatic route re-calculations live.',
    color: '#f43f5e',
    icon: Activity,
    animationType: 'TRAFFIC'
  },
  {
    id: 5,
    title: '5. Rule Inspector & Audit Log',
    time: '0:40 - 0:50',
    description: 'Review 100% mathematical proofs, symbolic logic checks, and transparent explainability trace logs in the right panel.',
    color: '#f59e0b',
    icon: ShieldCheck,
    animationType: 'AUDIT'
  }
];

export default function DemoVideoModal({ isOpen, onClose }) {
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [dontShowAgain, setDontShowAgain] = useState(false);

  const timerRef = useRef(null);

  // Initialize "Don't show again" from local storage
  useEffect(() => {
    const saved = localStorage.getItem('hide_demo_video');
    if (saved === 'true') {
      setDontShowAgain(true);
    }
  }, []);

  // Handle Play/Pause timer loop
  useEffect(() => {
    if (!isOpen) return;

    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setProgress((prevProgress) => {
          if (prevProgress >= 100) {
            // Move to next chapter or loop
            setCurrentChapterIndex((prevIdx) => (prevIdx + 1) % CHAPTERS.length);
            return 0;
          }
          return prevProgress + 2; // ~5 seconds per chapter
        });
      }, 100);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [isPlaying, isOpen]);

  if (!isOpen) return null;

  const currentChapter = CHAPTERS[currentChapterIndex];

  const handleToggleDontShow = (e) => {
    const checked = e.target.checked;
    setDontShowAgain(checked);
    if (checked) {
      localStorage.setItem('hide_demo_video', 'true');
    } else {
      localStorage.removeItem('hide_demo_video');
    }
  };

  const handleChapterClick = (index) => {
    setCurrentChapterIndex(index);
    setProgress(0);
    setIsPlaying(true);
  };

  const handleRestart = () => {
    setCurrentChapterIndex(0);
    setProgress(0);
    setIsPlaying(true);
  };

  const handleNext = () => {
    setCurrentChapterIndex((prev) => (prev + 1) % CHAPTERS.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentChapterIndex((prev) => (prev - 1 + CHAPTERS.length) % CHAPTERS.length);
    setProgress(0);
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 9999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(15, 23, 42, 0.75)',
      backdropFilter: 'blur(8px)',
      padding: '16px',
      overflowY: 'auto'
    }}>
      <div className="glass-panel" style={{
        width: '100%',
        maxWidth: '920px',
        maxHeight: '90vh',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: '#ffffff',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        border: '1px solid #cbd5e1',
        borderRadius: '16px',
        overflow: 'hidden'
      }}>
        {/* Header Bar */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '16px 24px',
          borderBottom: '1px solid #e2e8f0',
          background: 'linear-gradient(90deg, #1e293b 0%, #0f172a 100%)',
          color: '#ffffff'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              padding: '8px',
              background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
              borderRadius: '10px',
              boxShadow: '0 0 12px rgba(59, 130, 246, 0.5)'
            }}>
              <Film size={20} color="#ffffff" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: '700', color: '#ffffff', letterSpacing: '-0.3px' }}>
                Application Video Demo & Guided Walkthrough
              </h2>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0 }}>
                Learn how to dispatch routes, set vehicle rules, simulate traffic, and inspect logic proofs in 5 easy steps.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              color: '#ffffff',
              border: 'none',
              borderRadius: '8px',
              width: '36px',
              height: '36px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}
            title="Close Demo Video"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Main Content */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', flex: 1, minHeight: 0, overflow: 'hidden' }}>
          
          {/* Left Column: Animated Video Display Canvas & Controls */}
          <div style={{
            padding: '20px',
            background: '#0f172a',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px',
            justifyContent: 'space-between'
          }}>
            {/* Animated Screen Canvas Container */}
            <div style={{
              position: 'relative',
              width: '100%',
              height: '280px',
              background: '#1e293b',
              borderRadius: '12px',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              boxShadow: 'inset 0 2px 8px rgba(0, 0, 0, 0.5)'
            }}>
              {/* Top Watermark Badge */}
              <div style={{
                position: 'absolute',
                top: '12px',
                left: '12px',
                background: 'rgba(0, 0, 0, 0.6)',
                backdropFilter: 'blur(4px)',
                padding: '4px 10px',
                borderRadius: '20px',
                fontSize: '11px',
                fontWeight: '600',
                color: currentChapter.color,
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                border: `1px solid ${currentChapter.color}44`
              }}>
                <Sparkles size={12} /> Live Interactive Video Demo ({currentChapterIndex + 1}/5)
              </div>

              {/* Dynamic Demo Visual Screen Mockup per Chapter */}
              {currentChapter.animationType === 'NODES' && (
                <div style={{ textAlign: 'center', padding: '20px', color: '#f8fafc' }}>
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '16px' }}>
                    <div style={{ padding: '12px 18px', background: 'rgba(16, 185, 129, 0.15)', border: '1.5px solid #10b981', borderRadius: '10px' }}>
                      <span style={{ fontSize: '11px', color: '#6ee7b7' }}>ORIGIN</span>
                      <div style={{ fontWeight: '700', fontSize: '14px', color: '#ffffff' }}>Central Depot</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', color: '#64748b' }}>➔</div>
                    <div style={{ padding: '12px 18px', background: 'rgba(244, 63, 94, 0.15)', border: '1.5px solid #f43f5e', borderRadius: '10px' }}>
                      <span style={{ fontSize: '11px', color: '#fda4af' }}>DESTINATION</span>
                      <div style={{ fontWeight: '700', fontSize: '14px', color: '#ffffff' }}>Airport Cargo Hub</div>
                    </div>
                  </div>
                  <div style={{ background: 'rgba(255, 255, 255, 0.05)', padding: '10px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)', display: 'inline-flex', gap: '16px', fontSize: '12px', color: '#cbd5e1' }}>
                    <span>🚚 Max Height: <strong>3.8m</strong></span>
                    <span>⚖️ Weight: <strong>12.0t</strong></span>
                    <span>⚠️ Hazmat: <strong>Yes</strong></span>
                  </div>
                </div>
              )}

              {currentChapter.animationType === 'ASTAR' && (
                <div style={{ textAlign: 'center', padding: '20px', width: '90%' }}>
                  <div style={{ fontSize: '12px', color: '#38bdf8', marginBottom: '8px', fontWeight: '600' }}>
                    ⚡ DYNAMIC A* SHORTEST PATH CALCULATION
                  </div>
                  <div style={{ height: '8px', background: '#334155', borderRadius: '4px', overflow: 'hidden', margin: '12px 0' }}>
                    <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg, #3b82f6, #10b981)', transition: 'width 0.1s linear' }}></div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94a3b8' }}>
                    <span>Checking Edge Constraints...</span>
                    <span>Optimal Distance: <strong>14.2 km</strong></span>
                    <span>Est Time: <strong>18 min</strong></span>
                  </div>
                </div>
              )}

              {currentChapter.animationType === 'VRP' && (
                <div style={{ width: '85%', background: 'rgba(255,255,255,0.05)', padding: '14px', borderRadius: '10px', border: '1px solid #8b5cf666' }}>
                  <div style={{ fontSize: '13px', fontWeight: '700', color: '#c084fc', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Truck size={16} /> Google OR-Tools CVRPTW Solver Active
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '11px', color: '#e2e8f0' }}>
                    <div style={{ padding: '6px 10px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '6px', display: 'flex', justifyContent: 'space-between' }}>
                      <span>Fleet Truck #1 (Depot ➔ Downtown ➔ Airport)</span>
                      <span style={{ color: '#60a5fa' }}>Demand: 600kg</span>
                    </div>
                    <div style={{ padding: '6px 10px', background: 'rgba(16, 185, 129, 0.2)', borderRadius: '6px', display: 'flex', justifyContent: 'space-between' }}>
                      <span>Fleet Truck #2 (Depot ➔ North Port ➔ East Waterfront)</span>
                      <span style={{ color: '#34d399' }}>Demand: 850kg</span>
                    </div>
                  </div>
                </div>
              )}

              {currentChapter.animationType === 'TRAFFIC' && (
                <div style={{ textAlign: 'center', padding: '20px', color: '#f8fafc' }}>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: 'rgba(244, 63, 94, 0.2)', border: '1px solid #f43f5e', color: '#f43f5e', padding: '6px 14px', borderRadius: '20px', fontSize: '12px', fontWeight: '700', marginBottom: '12px' }}>
                    <Activity size={14} className="pulse-hazard" /> LIVE ACCIDENT INJECTED (Main Highway)
                  </div>
                  <div style={{ fontSize: '12px', color: '#94a3b8', maxWidth: '320px', margin: '0 auto' }}>
                    Edge speed dropped from <strong>60 km/h</strong> ➔ <strong>6 km/h</strong>. Routing engine re-calculates alternative bypass path automatically.
                  </div>
                </div>
              )}

              {currentChapter.animationType === 'AUDIT' && (
                <div style={{ width: '88%', background: '#090d16', padding: '12px', borderRadius: '8px', border: '1px solid #f59e0b44', fontFamily: 'monospace', fontSize: '11px' }}>
                  <div style={{ color: '#fbbf24', fontWeight: '700', marginBottom: '6px' }}>✓ SYMBOLIC LOGIC COMPLIANCE VERIFIED</div>
                  <div style={{ color: '#34d399' }}>[PASSED] Height Check: Vehicle 3.8m &lt; Tunnel Limit 4.5m</div>
                  <div style={{ color: '#34d399' }}>[PASSED] Weight Check: Gross 12.0t &lt; Bridge Limit 20.0t</div>
                  <div style={{ color: '#60a5fa' }}>[TRACE] Graph edge dynamic weights updated in 2ms</div>
                </div>
              )}

              {/* Bottom Video Timeline Progress Bar */}
              <div style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                height: '4px',
                background: 'rgba(255, 255, 255, 0.1)'
              }}>
                <div style={{
                  height: '100%',
                  width: `${progress}%`,
                  background: currentChapter.color,
                  transition: 'width 0.1s linear'
                }} />
              </div>
            </div>

            {/* Video Controls Bar */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: '#1e293b',
              padding: '10px 16px',
              borderRadius: '10px',
              border: '1px solid rgba(255, 255, 255, 0.08)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  style={{
                    background: currentChapter.color,
                    color: '#ffffff',
                    padding: '8px 14px',
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '12px',
                    fontWeight: '600'
                  }}
                >
                  {isPlaying ? <Pause size={14} /> : <Play size={14} />}
                  {isPlaying ? 'Pause Demo' : 'Play Demo'}
                </button>

                <button
                  onClick={handleRestart}
                  style={{
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: '#e2e8f0',
                    padding: '8px 12px',
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '12px'
                  }}
                >
                  <RotateCcw size={14} /> Replay
                </button>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <button
                  onClick={handlePrev}
                  style={{
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: '#ffffff',
                    padding: '6px 10px',
                    borderRadius: '6px',
                    fontSize: '12px'
                  }}
                >
                  <ChevronLeft size={16} />
                </button>
                <span style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600' }}>
                  {currentChapterIndex + 1} of {CHAPTERS.length}
                </span>
                <button
                  onClick={handleNext}
                  style={{
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: '#ffffff',
                    padding: '6px 10px',
                    borderRadius: '6px',
                    fontSize: '12px'
                  }}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>

            {/* Current Step Banner */}
            <div style={{
              background: `${currentChapter.color}15`,
              border: `1px solid ${currentChapter.color}40`,
              padding: '12px 16px',
              borderRadius: '10px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                <span style={{
                  padding: '2px 8px',
                  background: currentChapter.color,
                  color: '#ffffff',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '700'
                }}>
                  {currentChapter.time}
                </span>
                <h4 style={{ fontSize: '13px', fontWeight: '700', color: '#ffffff' }}>
                  {currentChapter.title}
                </h4>
              </div>
              <p style={{ fontSize: '12px', color: '#cbd5e1', margin: 0 }}>
                {currentChapter.description}
              </p>
            </div>
          </div>

          {/* Right Column: Step Cards & User Preference Options */}
          <div style={{
            padding: '20px',
            background: '#ffffff',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            gap: '16px',
            overflowY: 'auto'
          }}>
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: '700', color: '#0f172a', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Demo Chapters & Quick Guide
              </h3>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {CHAPTERS.map((chapter, idx) => {
                  const isActive = idx === currentChapterIndex;
                  const Icon = chapter.icon;

                  return (
                    <div
                      key={chapter.id}
                      onClick={() => handleChapterClick(idx)}
                      style={{
                        padding: '10px 14px',
                        borderRadius: '10px',
                        cursor: 'pointer',
                        background: isActive ? `${chapter.color}10` : '#f8fafc',
                        border: `1.5px solid ${isActive ? chapter.color : '#e2e8f0'}`,
                        transition: 'all 0.2s ease',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px'
                      }}
                    >
                      <div style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '8px',
                        background: isActive ? chapter.color : '#cbd5e1',
                        color: '#ffffff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: '700',
                        fontSize: '13px'
                      }}>
                        <Icon size={16} />
                      </div>

                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '12px', fontWeight: '700', color: isActive ? chapter.color : '#1e293b' }}>
                          {chapter.title}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>
                          {chapter.time}
                        </div>
                      </div>

                      {isActive && (
                        <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: chapter.color }} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Footer Actions & Optional Checkbox */}
            <div style={{
              borderTop: '1px solid #e2e8f0',
              paddingTop: '14px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px'
            }}>
              {/* Optional Show on Open Preference */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input
                  type="checkbox"
                  id="dont-show-again-chk"
                  checked={dontShowAgain}
                  onChange={handleToggleDontShow}
                  style={{ width: '16px', height: '16px', cursor: 'pointer' }}
                />
                <label htmlFor="dont-show-again-chk" style={{ fontSize: '12px', color: '#475569', cursor: 'pointer', fontWeight: '500' }}>
                  Do not show demo video automatically when I open the app
                </label>
              </div>

              {/* Action Button */}
              <button
                onClick={onClose}
                className="btn-primary"
                style={{
                  width: '100%',
                  justifyContent: 'center',
                  padding: '12px',
                  fontSize: '13px',
                  borderRadius: '10px'
                }}
              >
                <CheckCircle2 size={16} /> Skip & Start Using Application
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
