import React, { useState } from 'react';
import { Activity, AlertTriangle, Radio, Flame, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { injectTrafficEvent } from '../services/api';

export default function TrafficSimulator({ edges = [], wsStatus = 'DISCONNECTED', onTrafficInjected }) {
  const [selectedEdge, setSelectedEdge] = useState('');
  const [eventType, setEventType] = useState('ACCIDENT');
  const [speedFactor, setSpeedFactor] = useState(0.1);
  const [description, setDescription] = useState('Multi-vehicle collision on highway');
  const [loading, setLoading] = useState(false);

  const handleSimulate = async (e) => {
    if (e) e.preventDefault();
    if (!selectedEdge) return;

    const [u, v] = selectedEdge.split('|');
    setLoading(true);

    try {
      await injectTrafficEvent({
        event_id: `EVT_${Date.now()}`,
        edge_u: u,
        edge_v: v,
        event_type: eventType,
        speed_factor: parseFloat(speedFactor),
        description: description
      });

      if (onTrafficInjected) onTrafficInjected();
    } catch (err) {
      alert(`Traffic Injection Failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Quick preset incident injection for South Indian roads
  const handleQuickPreset = async (u, v, type, factor, desc) => {
    setLoading(true);
    try {
      await injectTrafficEvent({
        event_id: `EVT_${Date.now()}`,
        edge_u: u,
        edge_v: v,
        event_type: type,
        speed_factor: factor,
        description: desc
      });
      if (onTrafficInjected) onTrafficInjected();
    } catch (err) {
      alert(`Failed to inject incident: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Activity size={18} color="#ef4444" />
          <h3 style={{ fontSize: '14px', fontWeight: '700', color: '#0f172a' }}>Live Incident & Traffic Simulator</h3>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px' }}>
          <Radio size={12} color={wsStatus === 'CONNECTED' ? '#10b981' : '#f87171'} />
          <span style={{ color: wsStatus === 'CONNECTED' ? '#047857' : '#94a3b8', fontWeight: '600' }}>
            {wsStatus === 'CONNECTED' ? '● LIVE WS CONNECTED' : 'WS CONNECTING...'}
          </span>
        </div>
      </div>

      {/* 1-Click Quick Preset Incident Buttons */}
      <div>
        <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b', marginBottom: '6px', textTransform: 'uppercase' }}>
          ⚡ 1-Click Simulated Incidents (Triggers Live Re-Routing)
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          <button
            type="button"
            onClick={() => handleQuickPreset('DEPOT_BLR', 'NODE_CHENNAI', 'ROAD_CLOSURE', 0.0, 'Major Collision on NH48 Bengaluru-Chennai Expressway')}
            style={{ padding: '6px 10px', fontSize: '11px', fontWeight: '600', background: '#fee2e2', color: '#b91c1c', border: '1px solid #fca5a5', borderRadius: '6px', cursor: 'pointer' }}
          >
            🚨 Block NH48 (Bengaluru ➔ Chennai)
          </button>

          <button
            type="button"
            onClick={() => handleQuickPreset('DEPOT_BLR', 'NODE_MANGALURU', 'WEATHER_ALERT', 0.2, 'Landslide & Heavy Rain on Western Ghats NH75')}
            style={{ padding: '6px 10px', fontSize: '11px', fontWeight: '600', background: '#fef3c7', color: '#b45309', border: '1px solid #fcd34d', borderRadius: '6px', cursor: 'pointer' }}
          >
            ⛈️ Heavy Rain (Western Ghats NH75)
          </button>

          <button
            type="button"
            onClick={() => handleQuickPreset('DEPOT_BLR', 'NODE_SALEM', 'ACCIDENT', 0.1, 'Multi-truck crash on NH44 Salem Expressway')}
            style={{ padding: '6px 10px', fontSize: '11px', fontWeight: '600', background: '#fee2e2', color: '#b91c1c', border: '1px solid #fca5a5', borderRadius: '6px', cursor: 'pointer' }}
          >
            💥 Crash on NH44 (Salem Expressway)
          </button>

          <button
            type="button"
            onClick={() => handleQuickPreset('DEPOT_BLR', 'NODE_CHENNAI', 'CLEAR', 1.0, 'Highway cleared and reopened')}
            style={{ padding: '6px 10px', fontSize: '11px', fontWeight: '600', background: '#dcfce7', color: '#15803d', border: '1px solid #86efac', borderRadius: '6px', cursor: 'pointer' }}
          >
            🟢 Clear NH48 Blockage
          </button>
        </div>
      </div>

      {/* Manual Custom Incident Form */}
      <form onSubmit={handleSimulate} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr auto', gap: '10px', alignItems: 'end' }}>
        <div>
          <label style={{ fontSize: '11px', color: '#64748b', marginBottom: '4px', display: 'block', fontWeight: '600' }}>Select Road</label>
          <select value={selectedEdge} onChange={(e) => setSelectedEdge(e.target.value)} style={{ width: '100%', padding: '6px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '11px' }}>
            <option value="">-- Choose Road Segment --</option>
            {edges.map((e, idx) => (
              <option key={`edge-opt-${idx}`} value={`${e.u}|${e.v}`}>
                {e.road_name} ({e.live_speed_kmh} km/h)
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ fontSize: '11px', color: '#64748b', marginBottom: '4px', display: 'block', fontWeight: '600' }}>Incident Type</label>
          <select value={eventType} onChange={(e) => setEventType(e.target.value)} style={{ width: '100%', padding: '6px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '11px' }}>
            <option value="ACCIDENT">Accident</option>
            <option value="CONGESTION">Traffic Jam</option>
            <option value="WEATHER_ALERT">Storm / Flood</option>
            <option value="ROAD_CLOSURE">Total Closure</option>
          </select>
        </div>

        <div>
          <label style={{ fontSize: '11px', color: '#64748b', marginBottom: '4px', display: 'block', fontWeight: '600' }}>Traffic Factor</label>
          <select value={speedFactor} onChange={(e) => setSpeedFactor(e.target.value)} style={{ width: '100%', padding: '6px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '11px' }}>
            <option value={0.0}>0% (Road Closed)</option>
            <option value={0.1}>10% (Severe Crawl)</option>
            <option value={0.3}>30% (Heavy Congestion)</option>
            <option value={1.0}>100% (Clear Traffic)</option>
          </select>
        </div>

        <button type="submit" className="btn-danger" disabled={loading || !selectedEdge} style={{ height: '32px', padding: '0 12px', display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '12px' }}>
          <Flame size={14} /> Inject Event
        </button>
      </form>
    </div>
  );
}
