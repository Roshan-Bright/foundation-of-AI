import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, Polygon, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';

// Auto zoom and fit map bounds to route polylines & markers
function MapViewBoundsSetter({ activeRoutes, customOriginCoords, customDestCoords }) {
  const map = useMap();

  useEffect(() => {
    const points = [];
    if (customOriginCoords) {
      points.push([customOriginCoords.lat, customOriginCoords.lng]);
    }
    if (customDestCoords) {
      points.push([customDestCoords.lat, customDestCoords.lng]);
    }
    if (activeRoutes && activeRoutes.length > 0) {
      activeRoutes.forEach(r => {
        if (r.path_coordinates && r.path_coordinates.length > 0) {
          r.path_coordinates.forEach(pt => points.push([pt[0], pt[1]]));
        }
      });
    }

    if (points.length > 0) {
      try {
        const bounds = L.latLngBounds(points);
        map.fitBounds(bounds, { padding: [60, 60], maxZoom: 14 });
      } catch (e) {}
    }
  }, [activeRoutes, customOriginCoords, customDestCoords, map]);

  return null;
}

// Click listener sub-component
function MapClickHandler({ onMapClick }) {
  useMapEvents({
    click(e) {
      if (onMapClick) {
        onMapClick(e.latlng.lat, e.latlng.lng);
      }
    }
  });
  return null;
}

// Create custom icons for Leaflet markers
const createCustomIcon = (label, role = 'NORMAL', mode = 'CAR') => {
  let bgColor = '#3b82f6';
  let badgeText = label;
  let borderColor = '#1d4ed8';

  if (role === 'DEPOT') {
    bgColor = '#f59e0b';
    borderColor = '#d97706';
    badgeText = '★ HUB';
  } else if (role === 'ORIGIN') {
    bgColor = '#10b981';
    borderColor = '#047857';
    badgeText = '▶ START';
  } else if (role === 'DESTINATION') {
    bgColor = '#f43f5e';
    borderColor = '#be123c';
    badgeText = '🏁 END';
  } else if (role === 'VIA') {
    bgColor = '#8b5cf6';
    borderColor = '#6d28d9';
    badgeText = '📍 VIA';
  }

  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        background: ${bgColor};
        color: #ffffff;
        border: 2px solid ${borderColor};
        border-radius: 12px;
        padding: 2px 8px;
        font-weight: 700;
        font-size: 11px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 4px;
        transform: translate(-50%, -50%);
      ">
        <span>${badgeText}</span>
      </div>
    `,
    iconSize: [80, 24],
    iconAnchor: [40, 12]
  });
};

// Mode-specific route line styling rules (Distinct paths for Railway, Footpath, Bike track, Road)
const getPolylineStyle = (mode = 'CAR') => {
  switch (mode) {
    case 'METRO':
      return { color: '#a855f7', weight: 8, opacity: 0.95, lineCap: 'square', dashArray: '10, 10' }; // Railway track ties pattern
    case 'BUS':
      return { color: '#06b6d4', weight: 7, opacity: 0.95, lineCap: 'round', dashArray: null };      // Transit corridor line
    case 'MOTORCYCLE':
      return { color: '#eab308', weight: 6, opacity: 0.95, lineCap: 'round', dashArray: null };   // Motorcycle highway line
    case 'BICYCLE':
      return { color: '#84cc16', weight: 6, opacity: 0.95, lineCap: 'round', dashArray: '8, 8' };   // Greenway bike track
    case 'WALKING':
      return { color: '#f97316', weight: 6, opacity: 0.95, lineCap: 'round', dashArray: '4, 8' };   // Pedestrian footpath
    case 'TRUCK':
      return { color: '#6366f1', weight: 7, opacity: 0.95, lineCap: 'round', dashArray: null };
    case 'CAR':
    default:
      return { color: '#10b981', weight: 7, opacity: 0.95, lineCap: 'round', dashArray: null };    // Emerald car road
  }
};

export default function MapView({
  nodes = [],
  edges = [],
  avoidZones = [],
  activeRoutes = [],
  onSelectNode,
  onAddViaNode,
  onMapClick,
  selectedOrigin,
  selectedDestination,
  customOriginCoords,
  customDestCoords,
  viaNodes = []
}) {
  // Map Tile Layer state: GOOGLE_ROADMAP, GOOGLE_SATELLITE, GOOGLE_HYBRID, GOOGLE_TERRAIN, CARTO
  const [mapLayer, setMapLayer] = useState('GOOGLE_ROADMAP');

  // Center coordinates (Worldwide Default: Europe/Asia view center)
  const defaultCenter = [20.0000, 78.0000];

  // Tile layer URLs
  const tileLayers = {
    GOOGLE_ROADMAP: {
      url: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
      attribution: '&copy; Google Maps'
    },
    GOOGLE_SATELLITE: {
      url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
      attribution: '&copy; Google Maps Imagery'
    },
    GOOGLE_HYBRID: {
      url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
      attribution: '&copy; Google Maps Hybrid'
    },
    GOOGLE_TERRAIN: {
      url: 'https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}',
      attribution: '&copy; Google Maps Terrain'
    },
    CARTO: {
      url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
      attribution: '&copy; CARTO'
    }
  };

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      
      {/* Map Canvas Wrapper */}
      <div style={{ flex: 1, position: 'relative', width: '100%', height: '100%', minHeight: '300px', borderRadius: '12px', overflow: 'hidden' }}>
        
        {/* Top Floating Map Style Switcher (Google Maps Controls) */}
        <div className="glass-panel" style={{
          position: 'absolute',
          top: '12px',
          right: '12px',
          zIndex: 1000,
          padding: '6px 10px',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          background: 'rgba(255, 255, 255, 0.95)',
          borderRadius: '10px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.15)',
          border: '1px solid var(--border-color)'
        }}>
          <span style={{ fontSize: '11px', fontWeight: '700', color: '#1e293b', marginRight: '4px' }}>
            🗺️ Google Map Mode:
          </span>
          <button
            onClick={() => setMapLayer('GOOGLE_ROADMAP')}
            style={{
              padding: '4px 8px',
              fontSize: '11px',
              fontWeight: '700',
              borderRadius: '6px',
              border: 'none',
              background: mapLayer === 'GOOGLE_ROADMAP' ? '#4285F4' : '#e2e8f0',
              color: mapLayer === 'GOOGLE_ROADMAP' ? '#ffffff' : '#334155',
              cursor: 'pointer'
            }}
          >
            Roadmap
          </button>
          <button
            onClick={() => setMapLayer('GOOGLE_SATELLITE')}
            style={{
              padding: '4px 8px',
              fontSize: '11px',
              fontWeight: '700',
              borderRadius: '6px',
              border: 'none',
              background: mapLayer === 'GOOGLE_SATELLITE' ? '#4285F4' : '#e2e8f0',
              color: mapLayer === 'GOOGLE_SATELLITE' ? '#ffffff' : '#334155',
              cursor: 'pointer'
            }}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapLayer('GOOGLE_HYBRID')}
            style={{
              padding: '4px 8px',
              fontSize: '11px',
              fontWeight: '700',
              borderRadius: '6px',
              border: 'none',
              background: mapLayer === 'GOOGLE_HYBRID' ? '#4285F4' : '#e2e8f0',
              color: mapLayer === 'GOOGLE_HYBRID' ? '#ffffff' : '#334155',
              cursor: 'pointer'
            }}
          >
            Hybrid
          </button>
          <button
            onClick={() => setMapLayer('GOOGLE_TERRAIN')}
            style={{
              padding: '4px 8px',
              fontSize: '11px',
              fontWeight: '700',
              borderRadius: '6px',
              border: 'none',
              background: mapLayer === 'GOOGLE_TERRAIN' ? '#4285F4' : '#e2e8f0',
              color: mapLayer === 'GOOGLE_TERRAIN' ? '#ffffff' : '#334155',
              cursor: 'pointer'
            }}
          >
            Terrain
          </button>
        </div>

        {/* Floating Click-to-Route Instruction Banner */}
        <div style={{
          position: 'absolute',
          top: '12px',
          left: '12px',
          zIndex: 1000,
          padding: '6px 12px',
          background: 'rgba(15, 23, 42, 0.85)',
          color: '#ffffff',
          fontSize: '11px',
          fontWeight: '600',
          borderRadius: '8px',
          backdropFilter: 'blur(4px)',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
        }}>
          <span>💡 Click anywhere on the map to set Start (1st click) & End (2nd click)</span>
        </div>

        <MapContainer
          center={defaultCenter}
          zoom={5}
          scrollWheelZoom={true}
          style={{ width: '100%', height: '100%' }}
        >
          {/* Auto zoom & fit map viewport bounds to mode path */}
          <MapViewBoundsSetter
            activeRoutes={activeRoutes}
            customOriginCoords={customOriginCoords}
            customDestCoords={customDestCoords}
          />

          {/* Map click listener for setting start/destination anywhere on Earth */}
          <MapClickHandler onMapClick={onMapClick} />

          {/* Dynamic Tile Layer (Google Maps / Carto) */}
          <TileLayer
            key={mapLayer}
            attribution={tileLayers[mapLayer].attribution}
            url={tileLayers[mapLayer].url}
          />

          {/* 1. Restricted Eco & Clearance Hazard Polygons */}
          {avoidZones.map((zone) => {
            const positions = zone.polygon.map(pt => [pt.lat, pt.lng]);
            return (
              <Polygon
                key={zone.zone_id}
                positions={positions}
                pathOptions={{
                  color: '#e11d48',
                  fillColor: '#f43f5e',
                  fillOpacity: 0.25,
                  weight: 2,
                  dashArray: '6, 6'
                }}
              >
                <Popup>
                  <div style={{ color: '#0f172a', fontSize: '12px', minWidth: '180px' }}>
                    <div style={{ fontWeight: '700', color: '#e11d48', marginBottom: '4px' }}>
                      ⚠️ {zone.name}
                    </div>
                    {zone.max_height_m && <div>Clearance Height Limit: <strong>{zone.max_height_m}m</strong></div>}
                    {zone.disallow_hazmat && <div style={{ color: '#dc2626', fontWeight: '600' }}>🚫 Dangerous Hazmat Cargo Prohibited</div>}
                  </div>
                </Popup>
              </Polygon>
            );
          })}

          {/* 2. Base Infrastructure Lines */}
          {edges.map((edge, idx) => {
            const uNode = nodes.find(n => n.id === edge.u);
            const vNode = nodes.find(n => n.id === edge.v);
            if (!uNode || !vNode) return null;

            const positions = [
              [uNode.lat, uNode.lng],
              [vNode.lat, vNode.lng]
            ];

            let color = '#94a3b8';
            let weight = 2;
            if (edge.speed_factor <= 0.05) {
              color = '#ef4444';
              weight = 4;
            } else if (edge.speed_factor < 0.6) {
              color = '#f59e0b';
              weight = 3;
            }

            return (
              <Polyline
                key={`edge-${edge.u}-${edge.v}-${idx}`}
                positions={positions}
                pathOptions={{ color, weight, opacity: 0.4 }}
              />
            );
          })}

          {/* 3. Render Active Solution Route Line */}
          {activeRoutes.map((route, rIdx) => {
            const mode = route.transport_mode || 'CAR';
            const style = getPolylineStyle(mode);

            if (route.mode_legs && route.mode_legs.length > 0) {
              return (
                <React.Fragment key={`multimodal-route-${rIdx}`}>
                  {route.mode_legs.map((leg, lIdx) => {
                    const legStyle = getPolylineStyle(leg.transport_mode);
                    return (
                      <Polyline
                        key={`leg-${lIdx}`}
                        positions={leg.path_coordinates}
                        pathOptions={{
                          color: leg.color || legStyle.color,
                          weight: legStyle.weight,
                          opacity: legStyle.opacity,
                          lineCap: legStyle.lineCap,
                          dashArray: legStyle.dashArray
                        }}
                      >
                        <Popup>
                          <div style={{ fontSize: '12px', padding: '2px' }}>
                            <strong style={{ color: leg.color }}>Leg {leg.leg_index}: {leg.transport_mode}</strong><br />
                            {leg.line_name}<br />
                            Distance: <strong>{leg.distance_km} km</strong> | Time: <strong>{leg.time_min} mins</strong><br />
                            {leg.fare_inr > 0 && <div>Fare: <strong>₹{leg.fare_inr}</strong></div>}
                          </div>
                        </Popup>
                      </Polyline>
                    );
                  })}
                </React.Fragment>
              );
            }

            return (
              <React.Fragment key={route.route_id || `route-${rIdx}`}>
                <Polyline
                  positions={route.path_coordinates}
                  pathOptions={{
                    color: style.color,
                    weight: style.weight,
                    opacity: style.opacity,
                    lineCap: style.lineCap,
                    dashArray: style.dashArray
                  }}
                >
                  <Popup>
                    <div style={{ fontSize: '12px' }}>
                      <strong style={{ color: style.color }}>{mode} Route Path</strong><br />
                      Distance: <strong>{route.total_distance_km} km</strong> | Time: <strong>{route.total_time_min} mins</strong><br />
                      {route.fare_cost_inr > 0 && <div>Est. Cost: <strong>₹{route.fare_cost_inr}</strong></div>}
                      {route.co2_emissions_kg > 0 && <div>CO2 Emissions: <strong>{route.co2_emissions_kg} kg</strong></div>}
                    </div>
                  </Popup>
                </Polyline>
              </React.Fragment>
            );
          })}

          {/* Custom Clicked Origin Marker */}
          {customOriginCoords && (
            <Marker
              position={[customOriginCoords.lat, customOriginCoords.lng]}
              icon={createCustomIcon(customOriginCoords.name || 'Start Point', 'ORIGIN')}
            >
              <Popup>
                <div style={{ fontSize: '12px', fontWeight: '700', color: '#047857' }}>
                  ▶ Start Location<br />
                  <span style={{ fontWeight: '500', color: '#334155' }}>{customOriginCoords.name || `${customOriginCoords.lat.toFixed(4)}, ${customOriginCoords.lng.toFixed(4)}`}</span>
                </div>
              </Popup>
            </Marker>
          )}

          {/* Custom Clicked Destination Marker */}
          {customDestCoords && (
            <Marker
              position={[customDestCoords.lat, customDestCoords.lng]}
              icon={createCustomIcon(customDestCoords.name || 'Destination', 'DESTINATION')}
            >
              <Popup>
                <div style={{ fontSize: '12px', fontWeight: '700', color: '#be123c' }}>
                  🏁 End Destination<br />
                  <span style={{ fontWeight: '500', color: '#334155' }}>{customDestCoords.name || `${customDestCoords.lat.toFixed(4)}, ${customDestCoords.lng.toFixed(4)}`}</span>
                </div>
              </Popup>
            </Marker>
          )}

          {/* Pre-defined City Nodes */}
          {nodes.map((node) => {
            const isOrigin = selectedOrigin === node.id;
            const isDest = selectedDestination === node.id;
            const isVia = viaNodes.includes(node.id);

            let role = 'NORMAL';
            if (node.is_depot) role = 'DEPOT';
            if (isVia) role = 'VIA';
            if (isOrigin) role = 'ORIGIN';
            if (isDest) role = 'DESTINATION';

            return (
              <Marker
                key={node.id}
                position={[node.lat, node.lng]}
                icon={createCustomIcon(node.name.split(' ')[0], role)}
                eventHandlers={{
                  click: () => onSelectNode && onSelectNode(node.id)
                }}
              >
                <Popup>
                  <div style={{ color: '#0f172a', fontSize: '13px', padding: '4px', minWidth: '220px' }}>
                    <div style={{ fontWeight: '700', fontSize: '14px', marginBottom: '4px', color: '#1e293b' }}>
                      {node.name}
                    </div>
                    {node.metro_station && (
                      <div style={{ fontSize: '11px', color: '#a855f7', fontWeight: '600', marginBottom: '2px' }}>
                        🚇 {node.metro_station}
                      </div>
                    )}
                    {node.bus_terminal && (
                      <div style={{ fontSize: '11px', color: '#06b6d4', fontWeight: '600', marginBottom: '6px' }}>
                        🚌 {node.bus_terminal}
                      </div>
                    )}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '8px' }}>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button
                          onClick={() => onSelectNode && onSelectNode(node.id, 'ORIGIN')}
                          style={{ flex: 1, padding: '6px 8px', background: '#10b981', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '600', fontSize: '11px' }}
                        >
                          ▶ Set as Start
                        </button>
                        <button
                          onClick={() => onSelectNode && onSelectNode(node.id, 'DESTINATION')}
                          style={{ flex: 1, padding: '6px 8px', background: '#f43f5e', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '600', fontSize: '11px' }}
                        >
                          🏁 Set as End
                        </button>
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>

      {/* Mode Path Colors Legend Bar - Rendered BELOW the map (outside canvas) */}
      <div className="glass-panel" style={{
        padding: '10px 16px',
        fontSize: '12px',
        background: '#ffffff',
        border: '1px solid var(--border-color)',
        borderRadius: '10px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
        display: 'flex',
        alignItems: 'center',
        justify: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ fontWeight: '700', color: '#0f172a', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <span>🗺️ Mode Path Colors:</span>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap', color: '#334155' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#a855f7', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚇 Train / Metro Line</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#06b6d4', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚌 Bus Route</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#10b981', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚗 Car Drive</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#6366f1', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚚 Truck Route</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#eab308', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🏍️ Motorcycle</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#84cc16', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚴 Bicycle Track</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ width: '14px', height: '4px', background: '#f97316', borderRadius: '2px' }}></span>
            <span style={{ fontSize: '11px', fontWeight: '600' }}>🚶 Walk Footpath</span>
          </div>
        </div>
      </div>
    </div>
  );
}


