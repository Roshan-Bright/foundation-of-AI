import React, { useState, useEffect } from 'react';
import { Navigation, Zap, ArrowLeftRight, Search, MapPin, Compass } from 'lucide-react';

export default function DispatchPanel({
  nodes = [],
  onCalculateRoute,
  loading = false,
  customOriginCoords,
  setCustomOriginCoords,
  customDestCoords,
  setCustomDestCoords,
  origin,
  setOrigin,
  destination,
  setDestination
}) {
  const [transportMode, setTransportMode] = useState('CAR');

  // Search query states
  const [originSearch, setOriginSearch] = useState(customOriginCoords?.name || 'Bengaluru Majestic');
  const [destSearch, setDestSearch] = useState(customDestCoords?.name || 'Chennai Central');
  const [originResults, setOriginResults] = useState([]);
  const [destResults, setDestResults] = useState([]);
  const [isSearchingOrigin, setIsSearchingOrigin] = useState(false);
  const [isSearchingDest, setIsSearchingDest] = useState(false);

  // Sync search input with map clicks
  useEffect(() => {
    if (customOriginCoords?.name) {
      setOriginSearch(customOriginCoords.name);
    }
  }, [customOriginCoords]);

  useEffect(() => {
    if (customDestCoords?.name) {
      setDestSearch(customDestCoords.name);
    }
  }, [customDestCoords]);

  // Ground Transport Modes (No Air, No Water)
  const transportModes = [
    { id: 'CAR', icon: '🚗', name: 'Car / Road', color: '#10b981' },
    { id: 'METRO', icon: '🚇', name: 'Train / Metro', color: '#a855f7' },
    { id: 'BUS', icon: '🚌', name: 'Bus Transit', color: '#06b6d4' },
    { id: 'MOTORCYCLE', icon: '🏍️', name: 'Motorcycle', color: '#eab308' },
    { id: 'BICYCLE', icon: '🚴', name: 'Bicycle', color: '#84cc16' },
    { id: 'WALKING', icon: '🚶', name: 'Walking', color: '#f97316' },
    { id: 'MULTI_MODAL', icon: '🔀', name: 'Multi-Modal', color: '#ec4899' },
  ];

  // Worldwide Location Quick Presets
  const globalPresets = [
    {
      label: '🇫🇷 Paris ➔ 🇩🇪 Berlin',
      start: { lat: 48.8566, lng: 2.3522, name: 'Paris, France' },
      end: { lat: 52.5200, lng: 13.4050, name: 'Berlin, Germany' }
    },
    {
      label: '🇯🇵 Tokyo ➔ 🇯🇵 Osaka',
      start: { lat: 35.6762, lng: 139.6503, name: 'Tokyo, Japan' },
      end: { lat: 34.6937, lng: 135.5023, name: 'Osaka, Japan' }
    },
    {
      label: '🇺🇸 NYC ➔ 🇺🇸 Washington',
      start: { lat: 40.7128, lng: -74.0060, name: 'New York, USA' },
      end: { lat: 38.9072, lng: -77.0369, name: 'Washington DC, USA' }
    },
    {
      label: '🇮🇳 Bengaluru ➔ 🇮🇳 Chennai',
      start: { lat: 12.9716, lng: 77.5946, name: 'Bengaluru, India' },
      end: { lat: 13.0827, lng: 80.2707, name: 'Chennai, India' }
    }
  ];

  // Search Nominatim Geocoding API
  const handleSearchOrigin = async (query) => {
    setOriginSearch(query);
    if (!query || query.length < 2) {
      setOriginResults([]);
      return;
    }
    setIsSearchingOrigin(true);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`);
      const data = await res.json();
      setOriginResults(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearchingOrigin(false);
    }
  };

  const handleSearchDest = async (query) => {
    setDestSearch(query);
    if (!query || query.length < 2) {
      setDestResults([]);
      return;
    }
    setIsSearchingDest(true);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`);
      const data = await res.json();
      setDestResults(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearchingDest(false);
    }
  };

  const selectOriginLocation = (loc) => {
    const coords = { lat: parseFloat(loc.lat), lng: parseFloat(loc.lon), name: loc.display_name.split(',')[0] };
    setCustomOriginCoords(coords);
    setOriginSearch(coords.name);
    setOriginResults([]);
  };

  const selectDestLocation = (loc) => {
    const coords = { lat: parseFloat(loc.lat), lng: parseFloat(loc.lon), name: loc.display_name.split(',')[0] };
    setCustomDestCoords(coords);
    setDestSearch(coords.name);
    setDestResults([]);
  };

  // Swap Origin & Destination
  const handleSwap = () => {
    const tempCoords = customOriginCoords;
    const tempSearch = originSearch;
    setCustomOriginCoords(customDestCoords);
    setOriginSearch(destSearch);
    setCustomDestCoords(tempCoords);
    setDestSearch(tempSearch);
  };

  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    const payload = {
      transport_mode: transportMode,
    };

    if (customOriginCoords) {
      payload.origin_lat = customOriginCoords.lat;
      payload.origin_lng = customOriginCoords.lng;
      payload.origin_name = customOriginCoords.name;
    } else {
      payload.origin_id = origin;
    }

    if (customDestCoords) {
      payload.dest_lat = customDestCoords.lat;
      payload.dest_lng = customDestCoords.lng;
      payload.dest_name = customDestCoords.name;
    } else {
      payload.destination_id = destination;
    }

    onCalculateRoute(payload);
  };

  return (
    <div className="glass-panel" style={{ padding: '18px', display: 'flex', flexDirection: 'column', gap: '16px', height: '100%', overflowY: 'auto' }}>
      
      {/* Panel Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ padding: '8px', background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', borderRadius: '8px', color: '#ffffff' }}>
            <Navigation size={20} />
          </div>
          <div>
            <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#0f172a', letterSpacing: '-0.3px' }}>Google Maps Route Finder</h2>
            <p style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Click Map or Search Worldwide Locations</p>
          </div>
        </div>
      </div>

      {/* Worldwide Travel Mode Selector */}
      <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
        <div style={{ fontSize: '12px', fontWeight: '700', color: '#1e293b', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>Choose Transport Mode</span>
          <span style={{ fontSize: '10px', background: '#dcfce7', color: '#15803d', padding: '2px 6px', borderRadius: '4px', fontWeight: '700' }}>
            Ground Modes Only
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px' }}>
          {transportModes.map((m) => {
            const isSelected = transportMode === m.id;
            return (
              <button
                key={`mode-${m.id}`}
                type="button"
                onClick={() => {
                  setTransportMode(m.id);
                  if (customOriginCoords && customDestCoords) {
                    onCalculateRoute({
                      origin_lat: customOriginCoords.lat,
                      origin_lng: customOriginCoords.lng,
                      origin_name: customOriginCoords.name,
                      dest_lat: customDestCoords.lat,
                      dest_lng: customDestCoords.lng,
                      dest_name: customDestCoords.name,
                      transport_mode: m.id
                    });
                  }
                }}
                style={{
                  padding: '8px 4px',
                  fontSize: '11px',
                  fontWeight: '700',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  borderRadius: '6px',
                  border: isSelected ? `2px solid ${m.color}` : '1px solid #cbd5e1',
                  background: isSelected ? `${m.color}15` : '#ffffff',
                  color: isSelected ? m.color : '#475569',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease-in-out'
                }}
              >
                <span style={{ fontSize: '16px' }}>{m.icon}</span>
                <span style={{ fontSize: '10px', textAlign: 'center', whiteSpace: 'nowrap' }}>{m.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Worldwide Location Search inputs (Google Maps style) */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
        <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '10px', border: '1px solid #e2e8f0', position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ fontSize: '12px', fontWeight: '700', color: '#1e293b' }}>
              📍 Search Worldwide Locations
            </span>
            <button
              type="button"
              onClick={handleSwap}
              style={{ display: 'flex', alignItems: 'center', gap: '4px', background: '#e2e8f0', border: 'none', padding: '4px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', color: '#334155' }}
            >
              <ArrowLeftRight size={12} /> Swap
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {/* Start Location Input */}
            <div style={{ position: 'relative' }}>
              <label style={{ fontSize: '11px', color: '#047857', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                🟢 Start Point (Origin):
              </label>
              <div style={{ display: 'flex', alignItems: 'center', background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '0 8px', marginTop: '3px' }}>
                <Search size={14} color="#64748b" />
                <input
                  type="text"
                  value={originSearch}
                  onChange={(e) => handleSearchOrigin(e.target.value)}
                  placeholder="Type city or click on map..."
                  style={{ width: '100%', padding: '8px', border: 'none', outline: 'none', fontSize: '12px', color: '#0f172a' }}
                />
              </div>

              {/* Autocomplete Dropdown for Origin */}
              {originResults.length > 0 && (
                <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 9999, background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', marginTop: '2px', maxHeight: '180px', overflowY: 'auto' }}>
                  {originResults.map((loc, idx) => (
                    <div
                      key={`orig-loc-${idx}`}
                      onClick={() => selectOriginLocation(loc)}
                      style={{ padding: '8px 10px', fontSize: '11px', color: '#334155', borderBottom: '1px solid #f1f5f9', cursor: 'pointer', transition: 'background 0.15s' }}
                      onMouseEnter={(e) => e.target.style.background = '#f1f5f9'}
                      onMouseLeave={(e) => e.target.style.background = '#ffffff'}
                    >
                      📍 {loc.display_name}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Destination Location Input */}
            <div style={{ position: 'relative' }}>
              <label style={{ fontSize: '11px', color: '#be123c', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                🏁 End Point (Destination):
              </label>
              <div style={{ display: 'flex', alignItems: 'center', background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '0 8px', marginTop: '3px' }}>
                <Search size={14} color="#64748b" />
                <input
                  type="text"
                  value={destSearch}
                  onChange={(e) => handleSearchDest(e.target.value)}
                  placeholder="Type destination or click on map..."
                  style={{ width: '100%', padding: '8px', border: 'none', outline: 'none', fontSize: '12px', color: '#0f172a' }}
                />
              </div>

              {/* Autocomplete Dropdown for Destination */}
              {destResults.length > 0 && (
                <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 9999, background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', marginTop: '2px', maxHeight: '180px', overflowY: 'auto' }}>
                  {destResults.map((loc, idx) => (
                    <div
                      key={`dest-loc-${idx}`}
                      onClick={() => selectDestLocation(loc)}
                      style={{ padding: '8px 10px', fontSize: '11px', color: '#334155', borderBottom: '1px solid #f1f5f9', cursor: 'pointer', transition: 'background 0.15s' }}
                      onMouseEnter={(e) => e.target.style.background = '#f1f5f9'}
                      onMouseLeave={(e) => e.target.style.background = '#ffffff'}
                    >
                      📍 {loc.display_name}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Global Quick Presets */}
        <div>
          <div style={{ fontSize: '11px', fontWeight: '700', color: '#475569', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            🌍 Global One-Click Presets
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
            {globalPresets.map((preset, pIdx) => (
              <button
                key={`gpreset-${pIdx}`}
                type="button"
                onClick={() => {
                  setCustomOriginCoords(preset.start);
                  setCustomDestCoords(preset.end);
                  setOriginSearch(preset.start.name);
                  setDestSearch(preset.end.name);
                  onCalculateRoute({
                    origin_lat: preset.start.lat,
                    origin_lng: preset.start.lng,
                    origin_name: preset.start.name,
                    dest_lat: preset.end.lat,
                    dest_lng: preset.end.lng,
                    dest_name: preset.end.name,
                    transport_mode: transportMode
                  });
                }}
                style={{
                  fontSize: '11px',
                  padding: '7px 8px',
                  background: '#ffffff',
                  border: '1px solid #cbd5e1',
                  borderRadius: '6px',
                  color: '#1e293b',
                  cursor: 'pointer',
                  textAlign: 'left',
                  fontWeight: '600',
                  transition: 'all 0.2s'
                }}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <button
          type="submit"
          className="btn-primary"
          disabled={loading}
          style={{
            width: '100%',
            justifyContent: 'center',
            padding: '12px',
            fontSize: '14px',
            fontWeight: '700',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)'
          }}
        >
          {loading ? 'Routing Turn-by-Turn Path...' : '🗺️ Find Turn-by-Turn Path'}
        </button>
      </form>
    </div>
  );
}
