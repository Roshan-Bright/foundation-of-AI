import React from 'react';
import { ShieldCheck, AlertCircle, FileText, CheckCircle2, XCircle, MapPin, Clock, Navigation2, DollarSign, Leaf, Flame } from 'lucide-react';

export default function RuleInspector({ activeRoute, activeVRP }) {
  const evaluations = activeRoute?.rule_evaluations || (activeVRP?.routes?.[0]?.rule_evaluations) || [];
  const steps = activeRoute?.steps || [];
  const modeLegs = activeRoute?.mode_legs || [];
  const mode = activeRoute?.transport_mode || 'CAR';

  // Mode Icon map
  const modeIcons = {
    CAR: '🚗',
    METRO: '🚇',
    BUS: '🚌',
    TRUCK: '🚚',
    MOTORCYCLE: '🏍️',
    BICYCLE: '🚴',
    WALKING: '🚶',
    MULTI_MODAL: '🔀'
  };

  // Helper to format minutes to "Xh Ym"
  const formatTime = (totalMin = 0) => {
    const hrs = Math.floor(totalMin / 60);
    const mins = Math.round(totalMin % 60);
    if (hrs === 0) return `${mins} mins`;
    return `${hrs} hrs ${mins} mins`;
  };

  return (
    <div className="glass-panel" style={{ padding: '18px', display: 'flex', flexDirection: 'column', gap: '14px', height: '100%', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <ShieldCheck size={20} color="#10b981" />
          <h3 style={{ fontSize: '15px', fontWeight: '700', color: '#0f172a' }}>Route & Modal Inspector</h3>
        </div>
      </div>

      {/* Primary Route Summary Banner */}
      {activeRoute ? (
        <div style={{ background: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)', border: '1px solid #bfdbfe', borderRadius: '10px', padding: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ fontSize: '12px', fontWeight: '800', color: '#1e40af', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span>{modeIcons[mode] || '🚗'}</span>
              <span>{mode} ROUTE PATH</span>
            </span>
            <span style={{ fontSize: '11px', fontWeight: '700', color: '#15803d', background: '#dcfce7', padding: '2px 8px', borderRadius: '12px' }}>
              100% Path Verified
            </span>
          </div>

          {/* Primary Stats Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
            <div style={{ background: '#ffffff', padding: '8px 10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: '600' }}>TOTAL DISTANCE</div>
              <div style={{ fontSize: '18px', fontWeight: '800', color: '#1d4ed8' }}>
                {activeRoute.total_distance_km} km
              </div>
            </div>
            <div style={{ background: '#ffffff', padding: '8px 10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: '600' }}>TRAVEL DURATION</div>
              <div style={{ fontSize: '18px', fontWeight: '800', color: '#047857' }}>
                {formatTime(activeRoute.total_time_min)}
              </div>
            </div>
          </div>

          {/* Additional Modal Stats (Fare, CO2, Calories) */}
          <div style={{ display: 'grid', gridTemplateColumns: activeRoute.calories_burned > 0 ? '1fr 1fr 1fr' : '1fr 1fr', gap: '6px' }}>
            {activeRoute.fare_cost_inr > 0 && (
              <div style={{ background: '#f0fdf4', padding: '6px 8px', borderRadius: '6px', border: '1px solid #bbf7d0', fontSize: '11px' }}>
                <span style={{ color: '#166534', fontWeight: '600' }}>Est. Fare / Fuel:</span><br />
                <strong style={{ color: '#15803d', fontSize: '13px' }}>₹{activeRoute.fare_cost_inr}</strong>
              </div>
            )}
            {activeRoute.co2_emissions_kg !== undefined && (
              <div style={{ background: '#f8fafc', padding: '6px 8px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '11px' }}>
                <span style={{ color: '#475569', fontWeight: '600' }}>CO2 Footprint:</span><br />
                <strong style={{ color: '#0f172a', fontSize: '13px' }}>{activeRoute.co2_emissions_kg} kg</strong>
              </div>
            )}
            {activeRoute.calories_burned > 0 && (
              <div style={{ background: '#fff7ed', padding: '6px 8px', borderRadius: '6px', border: '1px solid #ffedd5', fontSize: '11px' }}>
                <span style={{ color: '#c2410c', fontWeight: '600' }}>Calories Burned:</span><br />
                <strong style={{ color: '#ea580c', fontSize: '13px' }}>{activeRoute.calories_burned} kcal</strong>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div style={{ padding: '16px', textAlign: 'center', background: '#f8fafc', border: '1px dashed #cbd5e1', borderRadius: '8px', color: '#64748b', fontSize: '12px' }}>
          👈 Choose your transport mode and click <strong>"Calculate Best Route"</strong> to see the exact polyline path.
        </div>
      )}

      {/* Multi-Modal Journey Legs Breakdown */}
      {modeLegs.length > 0 && (
        <div>
          <h4 style={{ fontSize: '12px', fontWeight: '700', color: '#334155', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            🔀 Multi-Modal Journey Breakdown ({modeLegs.length} Legs)
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {modeLegs.map((leg, lIdx) => (
              <div key={`mleg-${lIdx}`} style={{ background: '#ffffff', border: `1px solid ${leg.color || '#cbd5e1'}`, borderLeft: `4px solid ${leg.color || '#3b82f6'}`, borderRadius: '6px', padding: '8px 10px', fontSize: '11px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: '700', color: leg.color }}>
                    {modeIcons[leg.transport_mode]} Leg {leg.leg_index}: {leg.transport_mode}
                  </span>
                  <span style={{ fontWeight: '700', color: '#1e293b' }}>{leg.distance_km} km</span>
                </div>
                <div style={{ color: '#64748b', marginTop: '2px' }}>
                  {leg.from_name} ➔ {leg.to_name}
                </div>
                <div style={{ fontSize: '10px', color: '#94a3b8', marginTop: '2px', display: 'flex', justifyContent: 'space-between' }}>
                  <span>{leg.line_name}</span>
                  <span>Est: {leg.time_min} mins</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Turn-by-Turn Route & Transit Itinerary */}
      {steps.length > 0 && (
        <div>
          <h4 style={{ fontSize: '12px', fontWeight: '700', color: '#334155', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            🗺️ Detailed Segment Path Itinerary ({steps.length} Segments)
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '220px', overflowY: 'auto' }}>
            {steps.map((step, sIdx) => (
              <div key={`step-${sIdx}`} style={{ background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '8px 10px', fontSize: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: '700', color: '#1e293b' }}>
                    Segment {step.step_index}: {step.road_name}
                  </span>
                  <span style={{ fontWeight: '600', color: '#3b82f6' }}>{step.distance_km} km</span>
                </div>
                <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px', display: 'flex', justifyContent: 'space-between' }}>
                  <span>{step.from_node} ➔ {step.to_node}</span>
                  <span>Est: {step.time_min} mins ({step.live_speed_kmh} km/h)</span>
                </div>
                {step.hazards_detected && step.hazards_detected.length > 0 && (
                  <div style={{ fontSize: '10px', color: '#dc2626', fontWeight: '600', marginTop: '4px' }}>
                    ⚠️ {step.hazards_detected.join(', ')}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Safety & Constraint Evaluation Checks */}
      {evaluations.length > 0 && (
        <div>
          <h4 style={{ fontSize: '12px', fontWeight: '700', color: '#334155', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            🛡️ Safety & Policy Checks ({evaluations.length})
          </h4>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {evaluations.map((evalItem, idx) => (
              <div
                key={`rule-${idx}`}
                style={{
                  background: evalItem.passed ? '#f0fdf4' : '#fef2f2',
                  border: `1px solid ${evalItem.passed ? '#bbf7d0' : '#fecaca'}`,
                  borderRadius: '6px',
                  padding: '8px 10px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: '700', color: evalItem.passed ? '#15803d' : '#b91c1c' }}>
                    {evalItem.passed ? <CheckCircle2 size={15} color="#16a34a" /> : <XCircle size={15} color="#dc2626" />}
                    <span>{evalItem.rule_name}</span>
                  </div>
                  <span style={{ fontSize: '10px', fontWeight: '700', padding: '2px 6px', borderRadius: '4px', background: evalItem.passed ? '#dcfce7' : '#fee2e2', color: evalItem.passed ? '#166534' : '#991b1b' }}>
                    {evalItem.severity}
                  </span>
                </div>
                <div style={{ fontSize: '11px', color: '#334155' }}>
                  {evalItem.message}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

