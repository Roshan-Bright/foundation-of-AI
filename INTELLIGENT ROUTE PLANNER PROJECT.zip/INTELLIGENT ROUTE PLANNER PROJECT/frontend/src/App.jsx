import React, { useState, useEffect } from 'react';
import { Cpu, RefreshCw, Zap, Film, MapPin, Compass } from 'lucide-react';
import MapView from './components/MapView';
import DispatchPanel from './components/DispatchPanel';
import RuleInspector from './components/RuleInspector';
import DemoVideoModal from './components/DemoVideoModal';
import { fetchMapData, calculateRoute, optimizeVRP, createTrafficWebSocket } from './services/api';

export default function App() {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [avoidZones, setAvoidZones] = useState([]);
  
  // South India default origin & destination
  const [selectedOrigin, setSelectedOrigin] = useState('DEPOT_BLR');
  const [selectedDestination, setSelectedDestination] = useState('NODE_CHENNAI');
  const [viaNodes, setViaNodes] = useState(['NODE_SALEM']); // Default intermediate waypoint
  
  const [activeRoute, setActiveRoute] = useState(null);
  const [activeVRP, setActiveVRP] = useState(null);
  const [loading, setLoading] = useState(false);
  const [wsStatus, setWsStatus] = useState('DISCONNECTED');
  const [lastEvent, setLastEvent] = useState(null);

  // Demo Video Modal State
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(() => {
    return localStorage.getItem('hide_demo_video') !== 'true';
  });

  // Load Map Network
  const loadMap = async () => {
    try {
      const data = await fetchMapData();
      setNodes(data.nodes || []);
      setEdges(data.edges || []);
      setAvoidZones(data.avoid_zones || []);
    } catch (err) {
      console.error('Failed to fetch map data:', err);
    }
  };

  useEffect(() => {
    loadMap();

    // Connect WebSocket
    const ws = createTrafficWebSocket(
      (msg) => {
        if (msg.type === 'TRAFFIC_UPDATE') {
          setLastEvent(msg);
          // Refresh Map Graph to reflect live edge speeds instantly
          loadMap();

          // Auto re-trigger active route calculation if an active route exists!
          if (activeRoute) {
            handleCalculateRoute({
              origin_id: selectedOrigin,
              destination_id: selectedDestination,
              via_node_ids: viaNodes,
              vehicle: {
                vehicle_id: 'V-101',
                name: 'Standard Delivery Truck',
                capacity_kg: 1500,
                height_m: 3.2,
                weight_tons: 7.5,
                is_hazmat: false,
                max_continuous_drive_hours: 4.0
              },
              avoid_zones: []
            });
          }
        }
      },
      () => setWsStatus('DISCONNECTED')
    );

    if (ws) setWsStatus('CONNECTED');

    return () => {
      if (ws) ws.close();
    };
  }, []);

  const handleSelectNode = (nodeId, role) => {
    if (role === 'ORIGIN') {
      setSelectedOrigin(nodeId);
    } else if (role === 'DESTINATION') {
      setSelectedDestination(nodeId);
    } else {
      if (!selectedOrigin) setSelectedOrigin(nodeId);
      else setSelectedDestination(nodeId);
    }
  };

  const handleAddViaNode = (nodeId) => {
    if (!viaNodes.includes(nodeId) && nodeId !== selectedOrigin && nodeId !== selectedDestination) {
      setViaNodes([...viaNodes, nodeId]);
    }
  };

  // Custom Worldwide Coordinates State
  const [customOriginCoords, setCustomOriginCoords] = useState({ lat: 12.9716, lng: 77.5946, name: 'Bengaluru Majestic' });
  const [customDestCoords, setCustomDestCoords] = useState({ lat: 13.0827, lng: 80.2707, name: 'Chennai Central' });

  // Handle map click anywhere on the Earth map
  const handleMapClick = async (lat, lng) => {
    if (!customOriginCoords || (customOriginCoords && customDestCoords)) {
      // 1st click: set origin
      const newOrig = { lat, lng, name: `Location (${lat.toFixed(3)}, ${lng.toFixed(3)})` };
      setCustomOriginCoords(newOrig);
      setCustomDestCoords(null);
      
      // Reverse geocode
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
        const data = await res.json();
        if (data && data.display_name) {
          const name = data.address?.city || data.address?.town || data.address?.village || data.display_name.split(',')[0];
          setCustomOriginCoords({ lat, lng, name });
        }
      } catch (e) {}
    } else {
      // 2nd click: set destination & auto calculate route
      const newDest = { lat, lng, name: `Location (${lat.toFixed(3)}, ${lng.toFixed(3)})` };
      setCustomDestCoords(newDest);

      let destName = newDest.name;
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
        const data = await res.json();
        if (data && data.display_name) {
          destName = data.address?.city || data.address?.town || data.address?.village || data.display_name.split(',')[0];
          setCustomDestCoords({ lat, lng, name: destName });
        }
      } catch (e) {}

      handleCalculateRoute({
        origin_lat: customOriginCoords.lat,
        origin_lng: customOriginCoords.lng,
        origin_name: customOriginCoords.name,
        dest_lat: lat,
        dest_lng: lng,
        dest_name: destName,
        transport_mode: activeRoute?.transport_mode || 'CAR'
      });
    }
  };

  const handleCalculateRoute = async (payload) => {
    setLoading(true);
    setActiveVRP(null);
    try {
      const solution = await calculateRoute(payload);
      setActiveRoute(solution);
    } catch (err) {
      alert(`Route Calculation Notice: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleOptimizeVRP = async (payload) => {
    setLoading(true);
    setActiveRoute(null);
    try {
      const vrpSolution = await optimizeVRP(payload);
      setActiveVRP(vrpSolution);
    } catch (err) {
      alert(`Fleet Solver Notice: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Compile Active Routes to draw on Map
  const routesToRender = activeRoute ? [activeRoute] : (activeVRP?.routes || []);

  return (
    <div className="app-main-wrapper">
      {/* Demo Video Modal */}
      <DemoVideoModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
      />

      {/* Top Navbar */}
      <header className="glass-panel app-header" style={{ borderRadius: 0, padding: '12px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', zIndex: 1100, borderBottom: '1px solid var(--border-color)', background: '#ffffff' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ padding: '8px', background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', borderRadius: '10px', boxShadow: '0 0 15px rgba(16, 185, 129, 0.4)' }}>
            <Compass size={22} color="#ffffff" />
          </div>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '800', letterSpacing: '-0.5px', color: '#0f172a' }}>
               INTELLIGENT ROUTE PLANNER
            </h1>
            <p style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
              Real-Time Dynamic Routing • Live Waypoint Insertion • Traffic Incident Avoidance
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button
            onClick={() => setIsDemoModalOpen(true)}
            className="btn-primary"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)',
              boxShadow: '0 4px 12px rgba(139, 92, 246, 0.3)'
            }}
          >
            <Film size={15} /> 🎬 Watch Demo Video
          </button>

          <button onClick={loadMap} className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <RefreshCw size={14} /> Refresh Map
          </button>
        </div>
      </header>

      {/* Main Grid Layout */}
      <div className="app-main-grid">
        {/* Left Column: Dispatch Panel */}
        <DispatchPanel
          nodes={nodes}
          onCalculateRoute={handleCalculateRoute}
          onOptimizeVRP={handleOptimizeVRP}
          loading={loading}
          customOriginCoords={customOriginCoords}
          setCustomOriginCoords={setCustomOriginCoords}
          customDestCoords={customDestCoords}
          setCustomDestCoords={setCustomDestCoords}
          origin={selectedOrigin}
          setOrigin={setSelectedOrigin}
          destination={selectedDestination}
          setDestination={setSelectedDestination}
        />

        {/* Center Column: Map View */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', height: '100%', minHeight: 0 }}>
          {/* Map Container */}
          <div className="glass-panel map-container-wrapper" style={{ flex: 1, minHeight: '350px', overflow: 'hidden', position: 'relative' }}>
            <MapView
              nodes={nodes}
              edges={edges}
              avoidZones={avoidZones}
              activeRoutes={routesToRender}
              onSelectNode={handleSelectNode}
              onAddViaNode={handleAddViaNode}
              onMapClick={handleMapClick}
              selectedOrigin={selectedOrigin}
              selectedDestination={selectedDestination}
              customOriginCoords={customOriginCoords}
              customDestCoords={customDestCoords}
              viaNodes={viaNodes}
            />
          </div>
        </div>

        {/* Right Column: Rule Inspector & Driving Details */}
        <RuleInspector
          activeRoute={activeRoute}
          activeVRP={activeVRP}
        />
      </div>
    </div>
  );
}
