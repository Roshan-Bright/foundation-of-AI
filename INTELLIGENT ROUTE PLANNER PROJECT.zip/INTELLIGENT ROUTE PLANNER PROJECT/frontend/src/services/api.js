const getHost = () => {
  if (typeof window !== 'undefined' && window.location && window.location.hostname) {
    return window.location.hostname;
  }
  return 'localhost';
};

const API_BASE = `http://${getHost()}:8000`;
const WS_BASE = `ws://${getHost()}:8000/ws/traffic`;

export async function fetchMapData() {
  const res = await fetch(`${API_BASE}/api/map`);
  if (!res.ok) throw new Error('Failed to load map network data');
  return res.json();
}

export async function calculateRoute(payload) {
  const res = await fetch(`${API_BASE}/api/route`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || 'Routing request failed');
  }
  return res.json();
}

export async function optimizeVRP(payload) {
  const res = await fetch(`${API_BASE}/api/vrp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || 'VRP Fleet optimization failed');
  }
  return res.json();
}

export async function injectTrafficEvent(eventPayload) {
  const res = await fetch(`${API_BASE}/api/traffic/event`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(eventPayload)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || 'Failed to inject traffic event');
  }
  return res.json();
}

export function createTrafficWebSocket(onMessage, onError) {
  let ws = null;
  try {
    ws = new WebSocket(WS_BASE);
    ws.onmessage = (evt) => {
      try {
        const data = JSON.parse(evt.data);
        onMessage(data);
      } catch (e) {
        console.error('WS Parse Error', e);
      }
    };
    ws.onerror = (err) => {
      if (onError) onError(err);
    };
  } catch (e) {
    console.error('WebSocket connection error:', e);
  }
  return ws;
}
